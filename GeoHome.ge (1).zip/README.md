# GeoHome.ge - Real Estate Platform in Georgia

React + Supabase + Stripe

Multilingual: 🇬🇧 English & 🇬🇪 Georgian